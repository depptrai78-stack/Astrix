# Kaze 1.21.11 — A+B audit pass

## Changes made in this pass
- ChunkFinder now schedules its chunk scan and Hole ESP scan on all server types, rather than only on DonutSMP. The prior non-Donut branch called `handleSlowChunkFlagging`, which marked arbitrary loaded chunks as flagged and did not periodically refresh Hole ESP.
- Preserved the existing `HoleESP` BooleanSetting and its render toggle.
- Corrected `CameraMixin.onUpdateHead` parameter from `BlockView` to `World` to match the intended 1.21.11 Camera.update signature.
- Added null guards to the hitbox render mixin and Freecam block-outline mixin to avoid dereferencing an absent module manager/module during startup or teardown.
- NetheriteFinder remains excluded from compiled source and ModuleManager registration.

## Static audit findings still requiring follow-up
- ChunkFinder scan tasks still access Minecraft world/chunk/entity data from a background executor. This is a concurrency risk and should be moved to safe client-thread snapshots or a bounded client-thread scan before calling it fully stable.
- Trader scan methods exist but are not scheduled by normal module flow; trader-related settings/constants appear inactive.
- `ChunkFinder` still contains empty exception handlers, including hole scan paths, which can hide runtime failures.
- Several Mixin targets/signatures/accessors have not been verified against the resolved 1.21.11 Yarn artifacts. In particular, inspect `EntityRenderDispatcherMixin`, `FrustumAccessor`, `ChunkOcclusionDataBuilderMixin`, `TextVisitFactoryMixin`, `WorldChunkMixin`.
- `client.mixins.json` uses `defaultRequire: 0`; this avoids some launch failures but can silently disable injection behavior when a target no longer matches.
- Full module behavior for Combat/Donut/Misc/Render cannot be certified from static inspection alone.

## Build status
- Not built. This environment has JDK 21 but no Gradle executable, no Gradle Wrapper in the project, and network DNS is unavailable, so Gradle/Minecraft/Fabric dependencies could not be resolved.
- A direct `javac` attempt is not a valid project compile because Minecraft/Fabric/Gson dependencies are absent; it fails with missing-package/symbol errors. No Java parser/syntax errors were detected in that output, but that does not substitute for Gradle build.

## Recommended verification
1. Run `gradle build` (or add a Gradle Wrapper) with JDK 21 and network access.
2. Resolve compiler errors first; then launch the client and inspect `latest.log` for Mixin warnings.
3. Test Hole ESP toggle on/off, chunk scanning on singleplayer and a non-Donut server, and each module's enable/disable lifecycle.
