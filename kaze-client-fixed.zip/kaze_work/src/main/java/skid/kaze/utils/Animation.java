package skid.kaze.utils;

import skid.kaze.module.modules.client.Kaze;

public final class Animation {
   private double value;
   private final double end;

   public Animation(double end) {
      this.value = end;
      this.end = end;
   }

   public void animate(double speed, double target) {
      if (Kaze.animationMode.isMode(Kaze.AnimationMode.NORMAL)) {
         this.value = MathUtil.approachValue((float)speed, this.value, target);
      } else if (Kaze.animationMode.isMode(Kaze.AnimationMode.POSITIVE)) {
         this.value = MathUtil.smoothStep(speed, this.value, target);
      } else if (Kaze.animationMode.isMode(Kaze.AnimationMode.OFF)) {
         this.value = target;
      }

   }

   public double getAnimation() {
      return this.value;
   }

   public void setAnimation(double factor) {
      this.value = MathUtil.smoothStep(factor, this.value, this.end);
   }
}
