package skid.kaze.utils;

import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;
import skid.kaze.Kaze;

/**
 * Vanilla toast (top-right corner) helper. Must be called on the render thread.
 * All toasts share one Type, so a new toast updates the visible one instead of stacking a queue.
 */
public final class ToastUtil {
   private static final SystemToast.Type TYPE = new SystemToast.Type(6000L);

   /** @return true if the toast was queued, false if it could not be shown (caller may fall back to chat). */
   public static boolean show(CharSequence title, CharSequence description) {
      try {
         if (Kaze.mc == null || Kaze.mc.getToastManager() == null) {
            return false;
         }

         SystemToast.add(Kaze.mc.getToastManager(), TYPE, Text.literal(title.toString()), Text.literal(description.toString()));
         return true;
      } catch (Throwable t) {
         t.printStackTrace(System.err);
         return false;
      }
   }
}
