package skid.kaze.mixin;

import net.minecraft.util.math.Box;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import skid.kaze.Kaze;
import skid.kaze.module.Module;
import skid.kaze.module.modules.combat.Hitbox;

@Mixin({EntityRenderDispatcher.class})
public class EntityRenderDispatcherMixin {
   @ModifyVariable(
      method = {"renderHitbox"},
      ordinal = 0,
      at = @At(
   value = "STORE",
   ordinal = 0
)
   )
   private static Box onRenderHitboxEditBox(Box box) {
      Module hitboxes = Kaze.INSTANCE == null || Kaze.INSTANCE.MODULE_MANAGER == null
         ? null : Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(Hitbox.class);
      return hitboxes != null && hitboxes.isEnabled()
         ? box.expand(((Hitbox) hitboxes).getHitboxExpansion()) : box;
   }
}
