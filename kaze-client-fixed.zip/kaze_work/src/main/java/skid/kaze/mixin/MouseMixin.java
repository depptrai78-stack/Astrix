package skid.kaze.mixin;

import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.event.events.MouseButtonEvent;
import skid.kaze.event.events.MouseScrolledEvent;
import skid.kaze.manager.EventManager;

@Mixin({Mouse.class})
public abstract class MouseMixin {
   // 1.21.9+: Mouse.onMouseButton(long window, MouseInput input, int action)
   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseButton(long window, MouseInput input, int action, CallbackInfo ci) {
      if (input.button() != -1) {
         MouseButtonEvent event = new MouseButtonEvent(input.button(), window, action);
         EventManager.b(event);
         if (event.isCancelled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"onMouseScroll"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
      MouseScrolledEvent event = new MouseScrolledEvent(vertical);
      EventManager.b(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }
}
