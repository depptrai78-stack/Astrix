package skid.kaze.mixin;

import net.minecraft.client.Keyboard;
import net.minecraft.client.input.KeyInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import skid.kaze.event.events.KeyEvent;
import skid.kaze.manager.EventManager;

@Mixin({Keyboard.class})
public class KeyboardMixin {
   // 1.21.9+: Keyboard.onKey(long window, int action, KeyInput input)
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPress(long window, int action, KeyInput input, CallbackInfo ci) {
      if (input.key() != -1) {
         KeyEvent event = new KeyEvent(input.key(), window, action);
         EventManager.b(event);
         if (event.isCancelled()) {
            ci.cancel();
         }

      }
   }
}
