package skid.kaze.event.events;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import skid.kaze.event.CancellableEvent;

public class AttackBlockEvent extends CancellableEvent {
   public BlockPos pos;
   public Direction direction;

   public AttackBlockEvent(BlockPos pos, Direction direction) {
      this.pos = pos;
      this.direction = direction;
   }
}
