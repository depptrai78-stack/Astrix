package skid.kaze.event.events;

import net.minecraft.network.packet.Packet;
import skid.kaze.event.CancellableEvent;

public class PacketSendEvent extends CancellableEvent {
   public Packet<?> packet;

   public PacketSendEvent(Packet<?> packet) {
      this.packet = packet;
   }
}
