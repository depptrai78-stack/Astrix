package skid.kaze.event.events;

import net.minecraft.network.packet.Packet;
import skid.kaze.event.CancellableEvent;

public class PacketReceiveEvent extends CancellableEvent {
   public Packet<?> packet;

   public PacketReceiveEvent(Packet<?> packet) {
      this.packet = packet;
   }
}
