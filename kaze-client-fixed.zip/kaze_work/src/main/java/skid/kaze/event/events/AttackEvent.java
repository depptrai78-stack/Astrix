package skid.kaze.event.events;

import skid.kaze.event.CancellableEvent;

public class AttackEvent extends CancellableEvent {
}
