package skid.kaze;

import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      new Kaze();
   }
}
