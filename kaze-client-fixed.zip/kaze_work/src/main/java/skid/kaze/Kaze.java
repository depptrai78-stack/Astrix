package skid.kaze;

import java.io.File;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import skid.kaze.gui.ClickGUI;
import skid.kaze.manager.ConfigManager;
import skid.kaze.manager.EventManager;
import skid.kaze.module.ModuleManager;

public final class Kaze {
   public ConfigManager configManager;
   public ModuleManager MODULE_MANAGER;
   public EventManager EVENT_BUS;
   public static MinecraftClient mc;
   public String version;
   public static Kaze INSTANCE;
   public boolean shouldPreventClose;
   public ClickGUI GUI;
   public Screen screen;
   public long modified;
   public File jar;

   public Kaze() {
      // mc must be assigned first: modules/GUI read Kaze.mc while they are being constructed.
      mc = MinecraftClient.getInstance();
      INSTANCE = this;
      this.version = " b1.3";
      this.screen = null;
      this.shouldPreventClose = false;
      this.EVENT_BUS = new EventManager();

      try {
         this.MODULE_MANAGER = new ModuleManager();
         this.GUI = new ClickGUI();
         this.configManager = new ConfigManager();
         this.getConfigManager().loadProfile();
      } catch (Throwable t) {
         System.err.println("[Kaze] Initialisation failed - modules/GUI may be unavailable:");
         t.printStackTrace(System.err);
      }

      try {
         this.jar = new File(Kaze.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.modified = this.jar.lastModified();
      } catch (Throwable t) {
         // running from a dev environment (directory) - not fatal
      }

   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }

   public void resetModifiedDate() {
      if (this.jar != null) {
         this.jar.setLastModified(this.modified);
      }

   }
}
