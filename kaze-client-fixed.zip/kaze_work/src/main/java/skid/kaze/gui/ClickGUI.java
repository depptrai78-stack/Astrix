package skid.kaze.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import skid.kaze.Kaze;
import skid.kaze.module.Category;
import skid.kaze.utils.ColorUtil;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.TextRenderer;

public final class ClickGUI extends Screen {
   public List<CategoryWindow> windows = new ArrayList();
   public Color currentColor;
   private CharSequence tooltipText = null;
   private int tooltipX;
   private int tooltipY;
   private final Color DESCRIPTION_BG = new Color(40, 40, 40, 200);

   public ClickGUI() {
      super(Text.empty());
      int n = 50;
      Category[] values = Category.values();

      for(Category value : values) {
         this.windows.add(new CategoryWindow(n, 50, 230, 30, value, this));
         n += 250;
      }

   }

   public boolean isDraggingAlready() {
      for(CategoryWindow window : this.windows) {
         if (window.dragging) {
            return true;
         }
      }

      return false;
   }

   public void setTooltip(CharSequence tooltipText, int tooltipX, int tooltipY) {
      this.tooltipText = tooltipText;
      this.tooltipX = tooltipX;
      this.tooltipY = tooltipY;
   }

   public void setInitialFocus() {
      if (this.client != null) {
         super.setInitialFocus();
      }
   }

   public void render(DrawContext drawContext, int n, int n2, float n3) {
      if (Kaze.mc.currentScreen == this) {
         if (Kaze.INSTANCE.screen != null) {
            Kaze.INSTANCE.screen.render(drawContext, 0, 0, n3);
         }

         if (this.currentColor == null) {
            this.currentColor = new Color(0, 0, 0, 0);
         } else {
            this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
         }

         int alpha = this.currentColor.getAlpha();
         int n4;
         if (skid.kaze.module.modules.client.Kaze.renderBackground.getValue()) {
            n4 = 200;
         } else {
            n4 = 0;
         }

         if (alpha != n4) {
            int n5;
            if (skid.kaze.module.modules.client.Kaze.renderBackground.getValue()) {
               n5 = 200;
            } else {
               n5 = 0;
            }

            this.currentColor = ColorUtil.a(0.05F, n5, this.currentColor);
         }

         if (Kaze.mc.currentScreen instanceof ClickGUI) {
            drawContext.fill(0, 0, Kaze.mc.getWindow().getWidth(), Kaze.mc.getWindow().getHeight(), this.currentColor.getRGB());
         }

         RenderUtils.unscaledProjection(drawContext);
         int n6 = n * (int)MinecraftClient.getInstance().getWindow().getScaleFactor();
         int n7 = n2 * (int)MinecraftClient.getInstance().getWindow().getScaleFactor();
         super.render(drawContext, n6, n7, n3);

         for(CategoryWindow next : this.windows) {
            next.render(drawContext, n6, n7, n3);
            next.updatePosition((double)n6, (double)n7, n3);
         }

         if (this.tooltipText != null) {
            this.renderTooltip(drawContext, this.tooltipText, this.tooltipX, this.tooltipY);
            this.tooltipText = null;
         }

         RenderUtils.scaledProjection(drawContext);
      }

   }

   // 1.21.9+ input API: KeyInput / Click records instead of raw ints/doubles
   @Override
   public boolean keyPressed(KeyInput input) {
      for(CategoryWindow window : this.windows) {
         window.keyPressed(input.key(), input.scancode(), input.modifiers());
      }

      return super.keyPressed(input);
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      double sf = (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double x = click.x() * sf;
      double y = click.y() * sf;

      for(CategoryWindow window : this.windows) {
         window.mouseClicked(x, y, click.button());
      }

      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      double sf = (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double x = click.x() * sf;
      double y = click.y() * sf;

      for(CategoryWindow window : this.windows) {
         window.mouseDragged(x, y, click.button(), offsetX, offsetY);
      }

      return super.mouseDragged(click, offsetX, offsetY);
   }

   @Override
   public boolean mouseReleased(Click click) {
      double sf = (double)((int)MinecraftClient.getInstance().getWindow().getScaleFactor());
      double x = click.x() * sf;
      double y = click.y() * sf;

      for(CategoryWindow window : this.windows) {
         window.mouseReleased(x, y, click.button());
      }

      return super.mouseReleased(click);
   }

   @Override
   public boolean mouseScrolled(double n, double n2, double n3, double n4) {
      double n5 = n2 * MinecraftClient.getInstance().getWindow().getScaleFactor();

      for(CategoryWindow window : this.windows) {
         window.mouseScrolled(n, n5, n3, n4);
      }

      return super.mouseScrolled(n, n5, n3, n4);
   }

   public boolean shouldPause() {
      return false;
   }

   public void close() {
      Kaze.INSTANCE.getModuleManager().getModuleByClass(skid.kaze.module.modules.client.Kaze.class).setEnabled(false);
      this.onGuiClose();
   }

   public void onGuiClose() {
      Kaze.mc.setScreen(Kaze.INSTANCE.screen);
      this.currentColor = null;
      Iterator<CategoryWindow> iterator = this.windows.iterator();

      while(iterator.hasNext()) {
         ((CategoryWindow)iterator.next()).onGuiClose();
      }

   }

   private void renderTooltip(DrawContext drawContext, CharSequence charSequence, int n, int n2) {
      if (charSequence != null && charSequence.length() != 0) {
         int a = TextRenderer.getWidth(charSequence);
         int framebufferWidth = Kaze.mc.getWindow().getFramebufferWidth();
         if (n + a + 10 > framebufferWidth) {
            n = framebufferWidth - a - 10;
         }

         RenderUtils.renderRoundedQuad(drawContext, this.DESCRIPTION_BG, (double)(n - 5), (double)(n2 - 5), (double)(n + a + 5), (double)(n2 + 15), (double)6.0F, (double)6.0F, (double)6.0F, (double)6.0F, (double)50.0F);
         TextRenderer.drawString(charSequence, drawContext, n, n2, Color.WHITE.getRGB());
      }
   }

}
