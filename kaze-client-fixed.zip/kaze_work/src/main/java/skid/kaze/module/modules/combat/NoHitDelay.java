package skid.kaze.module.modules.combat;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.AttackEvent;
import skid.kaze.event.events.BlockBreakingEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;
import skid.kaze.utils.EncryptedString;

/**
 * Rebuilt from the Kaze "No Hit Delay" module (settings: Only Item, Item, Air, Blocks, Whitelist Blocks).
 * Cancels swings that would hit nothing / a block so a missed click does not reset the attack cooldown.
 * Never cancels a swing that targets an entity.
 */
public final class NoHitDelay extends Module {
   public enum Weapon {
      SWORD,
      AXE,
      BOTH
   }

   private final BooleanSetting onlyItem = (new BooleanSetting(EncryptedString.of("Only Item"), true)).setDescription(EncryptedString.of("Only works while holding the selected item"));
   private final ModeSetting<Weapon> item = new ModeSetting<Weapon>(EncryptedString.of("Item"), Weapon.BOTH, Weapon.class);
   private final BooleanSetting air = (new BooleanSetting(EncryptedString.of("Air"), true)).setDescription(EncryptedString.of("Cancels swings that would hit nothing"));
   private final BooleanSetting blocks = (new BooleanSetting(EncryptedString.of("Blocks"), true)).setDescription(EncryptedString.of("Cancels swings aimed at blocks (stops you from mining with your weapon)"));
   private final StringSetting whitelist = (new StringSetting(EncryptedString.of("Whitelist Blocks"), "")).setDescription(EncryptedString.of("Comma separated block ids that can still be hit, e.g. obsidian,minecraft:end_stone"));

   private String cachedRaw = null;
   private final Set<Block> cachedBlocks = new HashSet<>();

   public NoHitDelay() {
      super(EncryptedString.of("No Hit Delay"), EncryptedString.of("Doesn't let you miss your sword/axe hits"), -1, Category.COMBAT);
      this.addSettings(new Setting[]{this.onlyItem, this.item, this.air, this.blocks, this.whitelist});
   }

   @EventListener
   public void onAttack(AttackEvent event) {
      if (this.shouldCancel()) {
         event.cancel();
      }
   }

   @EventListener
   public void onBlockBreaking(BlockBreakingEvent event) {
      if (this.shouldCancel()) {
         event.cancel();
      }
   }

   private boolean shouldCancel() {
      if (this.mc.player == null || this.mc.world == null) {
         return false;
      }

      if (this.onlyItem.getValue() && !this.holdingSelectedItem()) {
         return false;
      }

      HitResult hit = this.mc.crosshairTarget;
      if (hit == null || hit.getType() == HitResult.Type.MISS) {
         return this.air.getValue();
      }

      if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult blockHit) {
         if (!this.blocks.getValue()) {
            return false;
         }

         Block block = this.mc.world.getBlockState(blockHit.getBlockPos()).getBlock();
         return !this.isWhitelisted(block);
      }

      return false;
   }

   private boolean holdingSelectedItem() {
      ItemStack stack = this.mc.player.getMainHandStack();
      boolean sword = stack.isIn(ItemTags.SWORDS);
      boolean axe = stack.getItem() instanceof AxeItem;
      if (this.item.getValue() == Weapon.SWORD) {
         return sword;
      } else if (this.item.getValue() == Weapon.AXE) {
         return axe;
      } else {
         return sword || axe;
      }
   }

   private boolean isWhitelisted(Block block) {
      String raw = this.whitelist.getValue();
      if (raw == null) {
         raw = "";
      }

      if (!raw.equals(this.cachedRaw)) {
         this.cachedRaw = raw;
         this.cachedBlocks.clear();

         for(String token : raw.split(",")) {
            String id = token.trim().toLowerCase(Locale.ROOT);
            if (id.isEmpty()) {
               continue;
            }

            if (!id.contains(":")) {
               id = "minecraft:" + id;
            }

            Identifier identifier = Identifier.tryParse(id);
            if (identifier != null && Registries.BLOCK.containsId(identifier)) {
               this.cachedBlocks.add(Registries.BLOCK.get(identifier));
            }
         }
      }

      return this.cachedBlocks.contains(block);
   }
}
