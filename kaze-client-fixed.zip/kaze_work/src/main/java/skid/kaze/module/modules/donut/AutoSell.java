package skid.kaze.module.modules.donut;

import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.item.Item.TooltipContext;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.ModeSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.InventoryUtil;

public final class AutoSell extends Module {
   private final ModeSetting<Mode> mode;
   private final ModeSetting<Items> item;
   private final NumberSetting delay;
   private int delayCounter;
   private boolean isSlotProcessed;

   public AutoSell() {
      super(EncryptedString.of("Auto Sell"), EncryptedString.of("Automatically sells pickles"), -1, Category.DONUT);
      this.mode = new ModeSetting<Mode>(EncryptedString.of("Mode"), AutoSell.Mode.SELL, Mode.class);
      this.item = new ModeSetting<Items>(EncryptedString.of("Item"), AutoSell.Items.SEAPICKLE, Items.class);
      this.delay = (new NumberSetting(EncryptedString.of("delay"), (double)0.0F, (double)20.0F, (double)2.0F, (double)1.0F)).getValue(EncryptedString.of("What should be delay in ticks"));
      this.addSettings(new Setting[]{this.mode, this.item, this.delay});
   }

   public void onEnable() {
      super.onEnable();
      this.delayCounter = 20;
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player != null) {
         if (this.delayCounter > 0) {
            --this.delayCounter;
         } else {
            if (this.mode.getValue().equals(AutoSell.Mode.SELL)) {
               ScreenHandler currentScreenHandler = this.mc.player.currentScreenHandler;
               if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) || ((GenericContainerScreenHandler)currentScreenHandler).getRows() != 5) {
                  this.mc.getNetworkHandler().sendChatCommand("sell");
                  this.delayCounter = 20;
                  return;
               }

               if (InventoryUtil.getSlot(net.minecraft.item.Items.AIR) > 0) {
                  int n;
                  Item item;
                  do {
                     n = 45;
                     item = ((ItemStack)this.mc.player.currentScreenHandler.getStacks().get(n)).getItem();
                  } while(item == net.minecraft.item.Items.AIR || !this.item.getValue().equals(AutoSell.Items.ALL) && !item.equals(this.getSelectedItem()));

                  this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, n, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.delayCounter = this.delay.getIntValue();
                  return;
               }

               this.mc.player.closeHandledScreen();
            } else {
               ScreenHandler fishHook = this.mc.player.currentScreenHandler;
               if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)) {
                  this.mc.getNetworkHandler().sendChatCommand("order " + this.getOrderCommand());
                  this.delayCounter = 20;
                  return;
               }

               if (((GenericContainerScreenHandler)fishHook).getRows() == 6) {
                  ItemStack stack = fishHook.getSlot(47).getStack();
                  if (stack.isOf(net.minecraft.item.Items.AIR)) {
                     this.delayCounter = 2;
                     return;
                  }

                  for(Object next : stack.getTooltip(TooltipContext.create(this.mc.world), this.mc.player, TooltipType.BASIC)) {
                     String string = next.toString();
                     if (string.contains("Most Money Per Item") && (((Text)next).getStyle().toString().contains("white") || string.contains("white"))) {
                        this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 47, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                        this.delayCounter = 5;
                        return;
                     }
                  }

                  for(int i = 0; i < 44; ++i) {
                     if (fishHook.getSlot(i).getStack().isOf(this.getSelectedItem())) {
                        this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, i, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                        this.delayCounter = 10;
                        return;
                     }
                  }

                  this.delayCounter = 40;
                  this.mc.player.closeHandledScreen();
                  return;
               }

               if (((GenericContainerScreenHandler)fishHook).getRows() == 4) {
                  int b = InventoryUtil.getSlot(net.minecraft.item.Items.AIR);
                  if (b <= 0) {
                     this.mc.player.closeHandledScreen();
                     this.delayCounter = 10;
                     return;
                  }

                  if (this.isSlotProcessed && b == 36) {
                     this.isSlotProcessed = false;
                     this.mc.player.closeHandledScreen();
                     return;
                  }

                  Item j = this.getSelectedItem();

                  while(true) {
                     int n2 = 36;
                     Item item2 = ((ItemStack)this.mc.player.currentScreenHandler.getStacks().get(36)).getItem();
                     if (item2 != net.minecraft.item.Items.AIR && item2 == j) {
                        this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 36, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                        this.delayCounter = this.delay.getIntValue();
                        if (this.delay.getIntValue() != 0) {
                           return;
                        }
                     }
                  }
               }

               if (((GenericContainerScreenHandler)fishHook).getRows() == 3) {
                  this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 15, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.delayCounter = 10;
                  return;
               }
            }

            this.delayCounter = 20;
         }
      }
   }

   private Item getSelectedItem() {
      Enum a = this.item.getValue();
      if (a == AutoSell.Items.ALL) {
         for(int i = 0; i < 35; ++i) {
            ItemStack stack = this.mc.player.getInventory().getStack(i);
            if (!stack.isOf(net.minecraft.item.Items.AIR)) {
               return stack.getItem();
            }
         }

         return net.minecraft.item.Items.AIR;
      } else {
         int n = a.ordinal() ^ 2132768360;
         int n2;
         if (n != 0) {
            n2 = (n * 31 >>> 4) % n ^ n >>> 16;
         } else {
            n2 = 0;
         }

         Item item = null;
         switch (n2) {
            case 105679470:
               item = net.minecraft.item.Items.BONE;
               break;
            case 105679471:
            case 105679473:
            case 105679475:
            case 105679477:
            default:
               item = net.minecraft.item.Items.AIR;
               break;
            case 105679472:
               item = net.minecraft.item.Items.PUMPKIN;
               break;
            case 105679474:
               item = net.minecraft.item.Items.BAMBOO;
               break;
            case 105679476:
               item = net.minecraft.item.Items.SWEET_BERRIES;
               break;
            case 105679478:
               item = net.minecraft.item.Items.SEA_PICKLE;
         }

         return item;
      }
   }

   private String getOrderCommand() {
      Item j = this.getSelectedItem();
      return j.equals(net.minecraft.item.Items.BONE) ? "Bones" : j.getName().getString();
   }

   static enum Items {
      SEAPICKLE("Sea_Pickle", 0),
      SWEETBERRIES("Sweet_Berries", 1),
      BAMBOO("Bamboo", 2),
      PUMPKIN("Pumpkin", 3),
      BONE("Bone", 4),
      ALL("All", 5);

      private Items(final String name, final int ordinal) {
      }

      // $FF: synthetic method
      private static Items[] $values() {
         return new Items[]{SEAPICKLE, SWEETBERRIES, BAMBOO, PUMPKIN, BONE, ALL};
      }
   }

   public static enum Mode {
      SELL("Sell", 0),
      ORDER("Order", 1);

      private Mode(final String name, final int ordinal) {
      }

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{SELL, ORDER};
      }
   }
}
