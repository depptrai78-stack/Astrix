package skid.kaze.module.modules.misc;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.module.setting.StringSetting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.embed.DiscordWebhook;

/**
 * Rebuilt from the Kaze "Auto Log" module (settings: Player Distance, Webhook, Ignore Friends;
 * webhook embed "AutoLog Detector" with "%.1f blocks"). This client has no friend list, so friends
 * are a comma separated name list in the "Friends" setting.
 */
public final class AutoLog extends Module {
   private final NumberSetting distance = (new NumberSetting(EncryptedString.of("Player Distance"), 5.0, 360.0, 50.0, 1.0)).getValue(EncryptedString.of("Logs off when a player comes closer than this many blocks"));
   private final StringSetting webhook = (new StringSetting(EncryptedString.of("Webhook"), "")).setDescription(EncryptedString.of("Discord webhook url, leave empty to disable"));
   private final BooleanSetting ignoreFriends = (new BooleanSetting(EncryptedString.of("Ignore Friends"), true)).setDescription(EncryptedString.of("Players listed in Friends do not trigger Auto Log"));
   private final StringSetting friends = (new StringSetting(EncryptedString.of("Friends"), "")).setDescription(EncryptedString.of("Comma separated player names"));

   public AutoLog() {
      super(EncryptedString.of("Auto Log"), EncryptedString.of("Automatically logs off when someone is near you"), -1, Category.MISC);
      this.addSettings(new Setting[]{this.distance, this.webhook, this.ignoreFriends, this.friends});
   }

   @EventListener
   public void onTick(TickEvent event) {
      ClientPlayerEntity self = this.mc.player;
      if (self == null || this.mc.world == null || self.networkHandler == null) {
         return;
      }

      double maxDistance = this.distance.getValue();

      for(PlayerEntity other : this.mc.world.getPlayers()) {
         if (other == self || this.isFriend(other)) {
            continue;
         }

         float dist = self.distanceTo(other);
         if ((double)dist <= maxDistance) {
            this.trigger(self, other, dist);
            return;
         }
      }
   }

   private boolean isFriend(PlayerEntity player) {
      if (!this.ignoreFriends.getValue()) {
         return false;
      }

      String raw = this.friends.getValue();
      if (raw == null || raw.isBlank()) {
         return false;
      }

      String name = player.getName().getString();

      for(String friend : raw.split(",")) {
         if (friend.trim().equalsIgnoreCase(name)) {
            return true;
         }
      }

      return false;
   }

   private void trigger(ClientPlayerEntity self, PlayerEntity other, float dist) {
      String name = other.getName().getString();
      String message = String.format(Locale.ROOT, "%s came within %.1f blocks", name, dist);
      this.sendWebhook(self, name, dist);
      this.toggle();
      MutableText text = Text.literal("[AutoLog] ");
      text.append(Text.of(message));
      self.networkHandler.onDisconnect(new DisconnectS2CPacket(text));
   }

   private void sendWebhook(ClientPlayerEntity self, String name, float dist) {
      String url = this.webhook.getValue();
      if (url == null || url.isBlank()) {
         return;
      }

      DiscordWebhook hook = new DiscordWebhook(url.trim());
      DiscordWebhook.EmbedObject embed = new DiscordWebhook.EmbedObject();
      embed.setTitle("AutoLog Detector");
      embed.setThumbnail("https://render.crafty.gg/3d/bust/" + String.valueOf(this.mc.getSession().getUuidOrNull()) + "?format=webp");
      embed.setDescription(this.mc.getSession().getUsername() + " logged out");
      embed.setColor(Color.RED);
      embed.setFooter(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), (String)null);
      embed.addField("Player", name, true);
      embed.addField("Distance", String.format(Locale.ROOT, "%.1f blocks", dist), true);
      embed.addField("Location", "x: " + (int)self.getX() + " y: " + (int)self.getY() + " z: " + (int)self.getZ(), true);
      hook.addEmbed(embed);
      Thread thread = new Thread(() -> {
         try {
            hook.execute();
         } catch (Throwable ignored) {
         }
      }, "AutoLog-Webhook");
      thread.setDaemon(true);
      thread.start();
   }
}
