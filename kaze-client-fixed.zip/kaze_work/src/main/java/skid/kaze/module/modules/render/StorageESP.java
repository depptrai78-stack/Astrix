package skid.kaze.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.BlockUtil;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;

public final class StorageESP extends Module {
   private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), (double)1.0F, (double)255.0F, (double)125.0F, (double)1.0F);
   private final BooleanSetting tracers = (new BooleanSetting(EncryptedString.of("Tracers"), false)).setDescription(EncryptedString.of("Draws a line from your player to the storage block"));
   private final BooleanSetting chests = new BooleanSetting(EncryptedString.of("Chests"), true);
   private final BooleanSetting enderChests = new BooleanSetting(EncryptedString.of("Ender Chests"), true);
   private final BooleanSetting spawners = new BooleanSetting(EncryptedString.of("Spawners"), true);
   private final BooleanSetting shulkerBoxes = new BooleanSetting(EncryptedString.of("Shulker Boxes"), true);
   private final BooleanSetting furnaces = new BooleanSetting(EncryptedString.of("Furnaces"), true);
   private final BooleanSetting barrels = new BooleanSetting(EncryptedString.of("Barrels"), true);
   private final BooleanSetting enchant = new BooleanSetting(EncryptedString.of("Enchanting Tables"), true);
   private final BooleanSetting pistons = new BooleanSetting(EncryptedString.of("Pistons"), true);

   public StorageESP() {
      super(EncryptedString.of("Storage ESP"), EncryptedString.of("Renders storage blocks through walls"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.alpha, this.tracers, this.chests, this.enderChests, this.spawners, this.shulkerBoxes, this.furnaces, this.barrels, this.enchant, this.pistons});
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      this.renderStorages(event);
   }

   /** Returns null when the block entity is not a tracked (or not enabled) storage type. */
   private Color getBlockEntityColor(BlockEntity blockEntity, int a) {
      if (blockEntity instanceof TrappedChestBlockEntity) {
         return this.chests.getValue() ? new Color(200, 91, 0, a) : null;
      } else if (blockEntity instanceof ChestBlockEntity) {
         return this.chests.getValue() ? new Color(156, 91, 0, a) : null;
      } else if (blockEntity instanceof EnderChestBlockEntity) {
         return this.enderChests.getValue() ? new Color(117, 0, 255, a) : null;
      } else if (blockEntity instanceof MobSpawnerBlockEntity) {
         return this.spawners.getValue() ? new Color(138, 126, 166, a) : null;
      } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
         return this.shulkerBoxes.getValue() ? new Color(134, 0, 158, a) : null;
      } else if (blockEntity instanceof FurnaceBlockEntity) {
         return this.furnaces.getValue() ? new Color(125, 125, 125, a) : null;
      } else if (blockEntity instanceof BarrelBlockEntity) {
         return this.barrels.getValue() ? new Color(255, 140, 140, a) : null;
      } else if (blockEntity instanceof EnchantingTableBlockEntity) {
         return this.enchant.getValue() ? new Color(80, 80, 255, a) : null;
      } else if (blockEntity instanceof PistonBlockEntity) {
         return this.pistons.getValue() ? new Color(35, 226, 0, a) : null;
      } else {
         return null;
      }
   }

   private void renderStorages(Render3DEvent event) {
      if (this.mc.world == null || this.mc.player == null) {
         return;
      }

      Camera cam = RenderUtils.getCamera();
      if (cam == null) {
         return;
      }

      Vec3d camPos = RenderUtils.getCameraPos();
      MatrixStack matrices = event.matrixStack;
      matrices.push();

      try {
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cam.getPitch()));
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(cam.getYaw() + 180.0F));
         matrices.translate(-camPos.x, -camPos.y, -camPos.z);
         Vec3d tracerStart = camPos.add(Vec3d.fromPolar(cam.getPitch(), cam.getYaw()).multiply(2.0));
         int a = this.alpha.getIntValue();
         boolean drawTracers = this.tracers.getValue();

         for(WorldChunk chunk : BlockUtil.getLoadedChunks().toList()) {
            for(BlockPos pos : new ArrayList<>(chunk.getBlockEntityPositions())) {
               BlockEntity blockEntity = this.mc.world.getBlockEntity(pos);
               if (blockEntity == null) {
                  continue;
               }

               Color fill = this.getBlockEntityColor(blockEntity, a);
               if (fill == null) {
                  continue;
               }

               RenderUtils.renderFilledBox(matrices, (float)pos.getX() + 0.1F, (float)pos.getY() + 0.05F, (float)pos.getZ() + 0.1F, (float)pos.getX() + 0.9F, (float)pos.getY() + 0.85F, (float)pos.getZ() + 0.9F, fill);
               if (drawTracers) {
                  Color line = this.getBlockEntityColor(blockEntity, 255);
                  RenderUtils.renderLine(matrices, line, tracerStart, new Vec3d((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5));
               }
            }
         }
      } finally {
         matrices.pop();
      }
   }
}
