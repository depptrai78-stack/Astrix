package skid.kaze.module.modules.misc;

import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.PacketReceiveEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.NumberSetting;
import skid.kaze.utils.EncryptedString;

public class PositionPacketFilter extends Module {
   private final BooleanSetting filterExtremePositions = (new BooleanSetting(EncryptedString.of("Filter Extreme Positions"), true)).setDescription(EncryptedString.of("Filters position packets with coordinates beyond normal Minecraft bounds"));
   private final NumberSetting maxCoordinate = (NumberSetting)(new NumberSetting(EncryptedString.of("Max Coordinate"), (double)100000.0F, (double)1.0E7F, (double)500000.0F, (double)10000.0F)).setDescription(EncryptedString.of("Maximum valid coordinate value (normal gameplay is ~-100k to +100k)"));

   public PositionPacketFilter() {
      super(EncryptedString.of("Position Packet Filter"), EncryptedString.of("Filters invalid position packets from server that cause ESP wobbling"), -1, Category.MISC);
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
      if (this.isEnabled() && this.filterExtremePositions.getValue() && packetReceiveEvent.packet instanceof PlayerPositionLookS2CPacket) {
         PlayerPositionLookS2CPacket playerPositionLookS2CPacket2 = (PlayerPositionLookS2CPacket)packetReceiveEvent.packet;
         double x = playerPositionLookS2CPacket2.change().position().x;
         double y = playerPositionLookS2CPacket2.change().position().y;
         double z = playerPositionLookS2CPacket2.change().position().z;
         double value = this.maxCoordinate.getValue();
         if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z) || Double.isInfinite(x) || Double.isInfinite(y) || Double.isInfinite(z) || Math.abs(x) > value || Math.abs(y) > value || Math.abs(z) > value) {
            packetReceiveEvent.cancel();
            System.out.println("[PositionPacketFilter] Blocked invalid position packet: x=" + x + " y=" + y + " z=" + z);
         }
      }

   }
}
