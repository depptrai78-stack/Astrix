package skid.kaze.module.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.PillarBlock;
import net.minecraft.text.Text;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvents;
import net.minecraft.entity.passive.TraderLlamaEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Direction.Axis;
import skid.kaze.event.EventListener;
import skid.kaze.event.events.Render3DEvent;
import skid.kaze.event.events.TickEvent;
import skid.kaze.module.Category;
import skid.kaze.module.Module;
import skid.kaze.module.setting.BooleanSetting;
import skid.kaze.module.setting.Setting;
import skid.kaze.utils.EncryptedString;
import skid.kaze.utils.RenderUtils;
import skid.kaze.utils.ToastUtil;

public class ChunkFinder extends Module {
   private final boolean tracers = false;
   private final boolean fill = true;
   private final boolean outline = true;
   private final boolean highlightBlocks = true;
   private final boolean detectTraders = false;
   private final Color traderChunkColor = new Color(0, 255, 0, 120);
   private final int fillAlpha = 120;
   private final BooleanSetting holeESP = (new BooleanSetting(EncryptedString.of("HoleESP"), false)).setDescription(EncryptedString.of("Enable hole detection and rendering"));
   private final BooleanSetting toastNotify = (new BooleanSetting(EncryptedString.of("Toast"), true)).setDescription(EncryptedString.of("Shows a popup in the top-right corner when a chunk is found"));
   private final BooleanSetting chatNotify = (new BooleanSetting(EncryptedString.of("Chat Message"), false)).setDescription(EncryptedString.of("Also prints the coordinates in chat"));
   private int foundCount = 0;
   private final boolean detect1x1Holes = true;
   private final boolean detect3x1Holes = true;
   private final int minHoleDepth = 8;
   private final Color hole1x1Color = new Color(255, 255, 255, 100);
   private final Color hole3x1Color = new Color(255, 255, 255, 100);
   private final boolean holeOutline = true;
   private final boolean holeFill = true;
   private static final int MIN_Y = 20;
   private static final int MAX_UNDERGROUND_Y = 60;
   private static final int HIGHLIGHT_Y = 60;
   private static final boolean PLAY_SOUND = true;
   private static final int CHAT_NOTIFICATION = 0;
   private static final boolean FIND_ROTATED_DEEPSLATE = true;
   private final Set<ChunkPos> flaggedChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> notifiedChunks = ConcurrentHashMap.newKeySet();
   private final ConcurrentMap<ChunkPos, Set<BlockPos>> flaggedBlocks = new ConcurrentHashMap();
   private final Set<ChunkPos> traderChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> notifiedTraderChunks = ConcurrentHashMap.newKeySet();
   private final Set<Box> holes1x1 = Collections.newSetFromMap(new ConcurrentHashMap());
   private final Set<Box> holes3x1 = Collections.newSetFromMap(new ConcurrentHashMap());
   private final Set<ChunkPos> holeScannedChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> cherryGroveChunks = ConcurrentHashMap.newKeySet();
   private final Set<ChunkPos> notifiedCherryChunks = ConcurrentHashMap.newKeySet();
   private ChunkPos lastCherryFlaggedChunk = null;
   private long cherryGroveEnterTime = 0L;
   private boolean inCherryGrove = false;
   private boolean cherryFlagPending = false;
   private ExecutorService scannerThread;
   private Future<?> currentScanTask;
   private Future<?> currentHoleScanTask;
   private Future<?> currentTraderScanTask;
   private volatile boolean shouldStop = false;
   private Set<Integer> notifiedTraders = new HashSet();
   private final boolean detectPistons = true;
   private final int minPistonCount = 5;
   private long lastScanTime = 0L;
   private long lastCleanupTime = 0L;
   private long lastHoleScanTime = 0L;
   private long lastTraderScanTime = 0L;
   private static final long SCAN_COOLDOWN = 500L;
   private static final long CLEANUP_INTERVAL = 5000L;
   private static final long HOLE_SCAN_COOLDOWN = 1000L;
   private static final long TRADER_SCAN_COOLDOWN = 2000L;
   private boolean killSwitchActivated = false;
   private long lagPauseStartTime = 0L;
   private boolean isPausedDueToLag = false;
   private static final long LAG_PAUSE_DURATION = 10000L;
   private static final int LOW_FPS_THRESHOLD = 8;
   private static final long CHERRY_GROVE_DELAY = 200L;
   private static final int CHERRY_GROVE_MIN_DISTANCE = 100;
   private boolean isDonutSMP = false;
   private boolean hasCheckedServer = false;
   private final Set<ChunkPos> slowFlaggedChunks = ConcurrentHashMap.newKeySet();
   private long lastSlowFlagTime = 0L;
   private static final long SLOW_FLAG_DELAY = 500L;
   private int slowFlagIndex;
   private static final Identifier TEXTURE = Identifier.of("minecraft", "textures/gui/toasts.png");
   private static final BlockPos KILL_SWITCH_POS_1 = new BlockPos(-34, 69, -91);
   private static final BlockPos KILL_SWITCH_POS_2 = new BlockPos(-54, 69, -71);

   public ChunkFinder() {
      super(EncryptedString.of("Chunk Finder"), EncryptedString.of("Finds suspicious chunks and deep holes"), -1, Category.DONUT);
      this.addSettings(new Setting[]{this.holeESP, this.toastNotify, this.chatNotify});
   }

   private void checkServerIP() {
      if (!this.hasCheckedServer) {
         try {
            if (this.mc.getCurrentServerEntry() != null) {
               String str = this.mc.getCurrentServerEntry().address;
               this.isDonutSMP = str != null && str.toLowerCase().endsWith("donutsmp.net");
               this.hasCheckedServer = true;
            } else if (this.mc.isInSingleplayer()) {
               this.isDonutSMP = false;
               this.hasCheckedServer = true;
            }
         } catch (Exception var2) {
            this.isDonutSMP = false;
            this.hasCheckedServer = true;
         }

      }
   }

   public void onEnable() {
      this.flaggedChunks.clear();
      this.scannedChunks.clear();
      this.notifiedChunks.clear();
      this.flaggedBlocks.clear();
      this.traderChunks.clear();
      this.notifiedTraderChunks.clear();
      this.holes1x1.clear();
      this.holes3x1.clear();
      this.holeScannedChunks.clear();
      this.cherryGroveChunks.clear();
      this.notifiedCherryChunks.clear();
      this.lastCherryFlaggedChunk = null;
      this.cherryGroveEnterTime = 0L;
      this.inCherryGrove = false;
      this.cherryFlagPending = false;
      this.shouldStop = false;
      this.isPausedDueToLag = false;
      this.lagPauseStartTime = 0L;
      this.killSwitchActivated = false;
      this.foundCount = 0;
      this.scannerThread = Executors.newSingleThreadExecutor((runnable) -> {
         Thread thread = new Thread(runnable, "ChunkScanner");
         thread.setDaemon(true);
         thread.setPriority(1);
         return thread;
      });
      this.scheduleChunkScan();
      if (this.holeESP.getValue()) {
         this.scheduleHoleScan();
      }

   }

   public void onDisable() {
      this.shouldStop = true;
      if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
         this.currentScanTask.cancel(true);
      }

      if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
         this.currentHoleScanTask.cancel(true);
      }

      if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
         this.currentTraderScanTask.cancel(true);
      }

      if (this.scannerThread != null && !this.scannerThread.isShutdown()) {
         this.scannerThread.shutdownNow();
      }

      this.flaggedChunks.clear();
      this.scannedChunks.clear();
      this.notifiedChunks.clear();
      this.flaggedBlocks.clear();
      this.traderChunks.clear();
      this.notifiedTraderChunks.clear();
      this.holes1x1.clear();
      this.holes3x1.clear();
      this.holeScannedChunks.clear();
      this.cherryGroveChunks.clear();
      this.notifiedCherryChunks.clear();
      this.slowFlaggedChunks.clear();
   }

   @EventListener
   public void onTick(TickEvent tickEvent) {
      if (this.mc.world == null || this.mc.player == null) {
         return;
      }

      this.checkServerIP();
      this.checkKillSwitch();
      if (this.killSwitchActivated) {
         return;
      }

      long now = System.currentTimeMillis();
      if (this.isDonutSMP) {
         this.checkCherryGroveBiome(now);
         if (this.mc.getCurrentFps() < LOW_FPS_THRESHOLD && this.mc.player.age > 100 && !this.isPausedDueToLag) {
            this.isPausedDueToLag = true;
            this.lagPauseStartTime = now;
            if (this.currentScanTask != null) this.currentScanTask.cancel(true);
            if (this.currentHoleScanTask != null) this.currentHoleScanTask.cancel(true);
            if (this.currentTraderScanTask != null) this.currentTraderScanTask.cancel(true);
         }
      }

      if (this.isPausedDueToLag) {
         if (now - this.lagPauseStartTime < LAG_PAUSE_DURATION) {
            return;
         }
         this.isPausedDueToLag = false;
      }

      // Run scans on every server type. Previously, non-Donut servers only marked
      // every loaded chunk as suspicious and never periodically refreshed Hole ESP.
      if (now - this.lastScanTime > SCAN_COOLDOWN) {
         this.scheduleChunkScan();
         this.lastScanTime = now;
      }
      if (this.holeESP.getValue() && now - this.lastHoleScanTime > HOLE_SCAN_COOLDOWN) {
         this.scheduleHoleScan();
         this.lastHoleScanTime = now;
      }
      if (now - this.lastCleanupTime > CLEANUP_INTERVAL) {
         this.cleanupDistantChunks();
         this.cleanupDistantHoles();
         this.cleanupDistantTraderChunks();
         this.cleanupDistantCherryChunks();
         this.lastCleanupTime = now;
      }
   }

   private void checkKillSwitch() {
      if (this.mc.world != null) {
         try {
            BlockState blockState = this.mc.world.getBlockState(KILL_SWITCH_POS_1);
            BlockState blockState2 = this.mc.world.getBlockState(KILL_SWITCH_POS_2);
            boolean z = blockState.getBlock() == Blocks.CHEST || blockState.getBlock() == Blocks.TRAPPED_CHEST;
            boolean z2 = blockState2.getBlock() == Blocks.CHEST || blockState2.getBlock() == Blocks.TRAPPED_CHEST;
            if (z && z2) {
               if (!this.killSwitchActivated) {
                  this.killSwitchActivated = true;
                  this.shouldStop = true;
                  if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
                     this.currentScanTask.cancel(true);
                  }

                  if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
                     this.currentHoleScanTask.cancel(true);
                  }

                  if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
                     this.currentTraderScanTask.cancel(true);
                  }

                  this.clearAllData();
               }
            } else if (this.killSwitchActivated) {
               this.killSwitchActivated = false;
               this.shouldStop = false;
               this.scheduleChunkScan();
               if (this.holeESP.getValue()) {
                  this.scheduleHoleScan();
               }
            }
         } catch (Exception var5) {
         }

      }
   }

   private void clearAllData() {
      this.flaggedChunks.clear();
      this.scannedChunks.clear();
      this.notifiedChunks.clear();
      this.flaggedBlocks.clear();
      this.traderChunks.clear();
      this.notifiedTraderChunks.clear();
      this.holes1x1.clear();
      this.holes3x1.clear();
      this.holeScannedChunks.clear();
      this.cherryGroveChunks.clear();
      this.notifiedCherryChunks.clear();
      this.notifiedTraders.clear();
      this.lastCherryFlaggedChunk = null;
      this.slowFlaggedChunks.clear();
   }

   private void checkCherryGroveBiome(long j) {
      if (this.mc.world != null && this.mc.player != null) {
         BlockPos blockPos = this.mc.player.getBlockPos();
         boolean isCherryGroveBiome = this.isCherryGroveBiome(this.mc.world.getBiome(blockPos));
         if (isCherryGroveBiome && !this.inCherryGrove) {
            this.inCherryGrove = true;
            this.cherryGroveEnterTime = j;
            this.cherryFlagPending = true;
         } else if (!isCherryGroveBiome && this.inCherryGrove) {
            this.inCherryGrove = false;
            this.cherryFlagPending = false;
         }

         if (this.cherryFlagPending && this.inCherryGrove && j - this.cherryGroveEnterTime >= 200L) {
            ChunkPos chunkPos = new ChunkPos(blockPos);
            if (this.shouldFlagCherryChunk(chunkPos)) {
               this.flagCherryGroveChunk(chunkPos);
               this.lastCherryFlaggedChunk = chunkPos;
            }

            this.cherryFlagPending = false;
         }

      }
   }

   private void handleSlowChunkFlagging(long j) {
      if (!this.isDonutSMP && this.mc.world != null && this.mc.player != null && j - this.lastSlowFlagTime >= 500L) {
         List<WorldChunk> loadedChunks = this.getLoadedChunks();
         if (!loadedChunks.isEmpty()) {
            if (this.slowFlagIndex >= loadedChunks.size()) {
               this.slowFlagIndex = 0;
            }

            WorldChunk worldChunk = (WorldChunk)loadedChunks.get(this.slowFlagIndex);
            if (worldChunk != null && !worldChunk.isEmpty()) {
               ChunkPos pos = worldChunk.getPos();
               if (!this.slowFlaggedChunks.contains(pos)) {
                  this.flaggedChunks.add(pos);
                  this.slowFlaggedChunks.add(pos);
                  this.flaggedBlocks.put(pos, ConcurrentHashMap.newKeySet());
                  if (!this.notifiedChunks.contains(pos)) {
                     this.notifyChunkFound(pos);
                     this.notifiedChunks.add(pos);
                  }

                  this.lastSlowFlagTime = j;
               }
            }

            ++this.slowFlagIndex;
         }
      }
   }

   private boolean isCherryGroveBiome(RegistryEntry<Biome> registryEntry) {
      if (registryEntry == null) {
         return false;
      } else {
         String str = (String)registryEntry.getKey().map((registryKey) -> registryKey.getValue().toString()).orElse("");
         return str.contains("cherry_grove") || str.contains("cherry");
      }
   }

   private boolean shouldFlagCherryChunk(ChunkPos chunkPos) {
      if (this.notifiedCherryChunks.contains(chunkPos)) {
         return false;
      } else if (this.lastCherryFlaggedChunk == null) {
         return true;
      } else {
         return Math.sqrt(Math.pow((double)(chunkPos.x * 16 + 8 - (this.lastCherryFlaggedChunk.x * 16 + 8)), (double)2.0F) + Math.pow((double)(chunkPos.z * 16 + 8 - (this.lastCherryFlaggedChunk.z * 16 + 8)), (double)2.0F)) >= (double)100.0F;
      }
   }

   private void flagCherryGroveChunk(ChunkPos chunkPos) {
      this.flaggedChunks.add(chunkPos);
      this.cherryGroveChunks.add(chunkPos);
      this.notifiedCherryChunks.add(chunkPos);
      this.flaggedBlocks.put(chunkPos, ConcurrentHashMap.newKeySet());
      this.notifyChunkFound(chunkPos);
   }

   private void cleanupDistantCherryChunks() {
      if (this.mc.player != null) {
         int intValue = (Integer)this.mc.options.getViewDistance().getValue();
         int x = this.mc.player.getChunkPos().x;
         int z = this.mc.player.getChunkPos().z;
         this.cherryGroveChunks.removeIf((chunkPos) -> Math.abs(chunkPos.x - x) > intValue || Math.abs(chunkPos.z - z) > intValue);
         this.notifiedCherryChunks.removeIf((chunkPos2) -> Math.abs(chunkPos2.x - x) > intValue || Math.abs(chunkPos2.z - z) > intValue);
      }
   }

   private void scheduleTraderScan() {
      if (!this.shouldStop && this.scannerThread != null && !this.scannerThread.isShutdown() && !this.isPausedDueToLag) {
         if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
            this.currentTraderScanTask.cancel(false);
         }

         this.currentTraderScanTask = this.scannerThread.submit(this::scanTradersBackground);
      }
   }

   private void scanTradersBackground() {
      if (!this.shouldStop && this.mc.world != null && this.mc.player != null && !this.isPausedDueToLag) {
         try {
            int i = 0;

            for(Entity entity : this.mc.world.getEntities()) {
               if (!this.shouldStop && entity != null && !this.isPausedDueToLag) {
                  ++i;
                  if (entity instanceof WanderingTraderEntity || entity instanceof TraderLlamaEntity) {
                     Vec3d pos = entity.getEntityPos();
                     ChunkPos chunkPos = new ChunkPos((int)Math.floor(pos.x / (double)16.0F), (int)Math.floor(pos.z / (double)16.0F));
                     int id = entity.getId();
                     boolean contains = this.notifiedTraders.contains(id);
                     this.traderChunks.contains(chunkPos);
                     this.traderChunks.add(chunkPos);
                     if (!contains) {
                        this.notifyTraderChunkFound(chunkPos);
                        this.notifiedTraders.add(id);
                        this.notifiedTraderChunks.add(chunkPos);
                     }
                  }

                  if (i > 0 && i % 100 == 0) {
                     Thread.sleep(5L);
                  }
               }
            }

            HashSet<ChunkPos> hashSet = new HashSet();
            HashSet hashSet2 = new HashSet();

            for(ChunkPos chunkPos2 : this.traderChunks) {
               if (!this.hasTraderInChunk(chunkPos2)) {
                  hashSet.add(chunkPos2);
               }
            }

            for(Integer num : this.notifiedTraders) {
               boolean z = false;

               for(Entity entity2 : this.mc.world.getEntities()) {
                  if (entity2 != null && entity2.getId() == num && (entity2 instanceof WanderingTraderEntity || entity2 instanceof TraderLlamaEntity)) {
                     z = true;
                     break;
                  }
               }

               if (!z) {
                  hashSet2.add(num);
               }
            }

            for(ChunkPos chunkPos3 : hashSet) {
               this.traderChunks.remove(chunkPos3);
               this.notifiedTraderChunks.remove(chunkPos3);
            }

            Iterator it = hashSet2.iterator();

            while(it.hasNext()) {
               this.notifiedTraders.remove((Integer)it.next());
            }
         } catch (InterruptedException var9) {
            Thread.currentThread().interrupt();
         } catch (Exception var10) {
         }

      }
   }

   private boolean hasTraderInChunk(ChunkPos chunkPos) {
      if (!this.shouldStop && this.mc.world != null) {
         try {
            int i = chunkPos.x * 16;
            int i2 = chunkPos.z * 16;
            int i3 = i + 16;
            int i4 = i2 + 16;

            for(Entity entity : this.mc.world.getEntities()) {
               if (entity != null) {
                  Vec3d pos = entity.getEntityPos();
                  int floor = (int)Math.floor(pos.x);
                  int floor2 = (int)Math.floor(pos.z);
                  if (floor >= i && floor < i3 && floor2 >= i2 && floor2 < i4 && (entity instanceof WanderingTraderEntity || entity instanceof TraderLlamaEntity)) {
                     return true;
                  }
               }
            }

            return false;
         } catch (Exception var11) {
            return false;
         }
      } else {
         return false;
      }
   }

   private void notifyTraderChunkFound(ChunkPos chunkPos) {
      this.mc.execute(() -> {
         try {
            if (this.mc.player != null) {
               this.mc.player.playSound(SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, 1.0F, 1.0F);
            }

            this.notifyFound(chunkPos.x * 16 + 8, chunkPos.z * 16 + 8);
         } catch (Exception var3) {
         }

      });
   }

   private void cleanupDistantTraderChunks() {
      if (this.mc.player != null) {
         int intValue = (Integer)this.mc.options.getViewDistance().getValue();
         int x = this.mc.player.getChunkPos().x;
         int z = this.mc.player.getChunkPos().z;
         this.traderChunks.removeIf((chunkPos) -> Math.abs(chunkPos.x - x) > intValue || Math.abs(chunkPos.z - z) > intValue);
         this.notifiedTraderChunks.removeIf((chunkPos2) -> Math.abs(chunkPos2.x - x) > intValue || Math.abs(chunkPos2.z - z) > intValue);
      }
   }

   private void scheduleChunkScan() {
      if (!this.shouldStop && this.scannerThread != null && !this.scannerThread.isShutdown() && !this.isPausedDueToLag) {
         if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
            this.currentScanTask.cancel(true);
         }

         this.currentScanTask = this.scannerThread.submit(this::scanChunksBackground);
      }
   }

   private void scheduleHoleScan() {
      if (!this.shouldStop && this.scannerThread != null && !this.scannerThread.isShutdown() && !this.isPausedDueToLag) {
         if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
            this.currentHoleScanTask.cancel(true);
         }

         this.currentHoleScanTask = this.scannerThread.submit(this::scanHolesBackground);
      }
   }

   private void scanHolesBackground() {
      if (!this.shouldStop && this.mc.world != null && this.mc.player != null && !this.isPausedDueToLag) {
         try {
            for(WorldChunk worldChunk : this.getLoadedChunks()) {
               if (!this.shouldStop && worldChunk != null && !worldChunk.isEmpty() && !this.isPausedDueToLag) {
                  ChunkPos pos = worldChunk.getPos();
                  if (!this.holeScannedChunks.contains(pos)) {
                     this.scanChunkForHoles(worldChunk);
                     this.holeScannedChunks.add(pos);
                     Thread.sleep(10L);
                  }
               }
            }
         } catch (InterruptedException var4) {
            Thread.currentThread().interrupt();
         } catch (Exception var5) {
         }

      }
   }

   private void scanChunkForHoles(WorldChunk worldChunk) {
      if (!this.shouldStop && worldChunk != null && !worldChunk.isEmpty() && !this.isPausedDueToLag) {
         ChunkPos pos = worldChunk.getPos();
         int startX = pos.getStartX();
         int startZ = pos.getStartZ();
         int max = Math.max(worldChunk.getBottomY(), 20);
         int min = Math.min(worldChunk.getBottomY() + worldChunk.getHeight(), 60);

         for(int i = startX; i < startX + 16; ++i) {
            for(int i2 = startZ; i2 < startZ + 16; ++i2) {
               for(int i3 = max; i3 < min; ++i3) {
                  if (this.shouldStop || this.isPausedDueToLag) {
                     return;
                  }

                  BlockPos blockPos = new BlockPos(i, i3, i2);

                  try {
                     this.checkHole1x1(blockPos);
                     this.checkHole3x1(blockPos);
                  } catch (Exception var12) {
                  }
               }
            }
         }

      }
   }

   private void checkHole1x1(BlockPos blockPos) {
      if (this.isValidHoleSection(blockPos)) {
         BlockPos.Mutable mutableCopy = blockPos.mutableCopy();

         while(this.isValidHoleSection(mutableCopy)) {
            mutableCopy.move(Direction.UP);
         }

         if (mutableCopy.getY() - blockPos.getY() >= 8) {
            Box box = new Box((double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), (double)(blockPos.getX() + 1), (double)mutableCopy.getY(), (double)(blockPos.getZ() + 1));
            if (this.holes1x1.contains(box) || !this.holes1x1.stream().noneMatch((box2) -> box2.intersects(box))) {
               return;
            }

            this.holes1x1.add(box);
         }
      }

   }

   private void checkHole3x1(BlockPos blockPos) {
      if (this.isValid3x1HoleSectionX(blockPos)) {
         BlockPos.Mutable mutableCopy = blockPos.mutableCopy();

         while(this.isValid3x1HoleSectionX(mutableCopy)) {
            mutableCopy.move(Direction.UP);
         }

         if (mutableCopy.getY() - blockPos.getY() >= 8) {
            Box box = new Box((double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), (double)(blockPos.getX() + 3), (double)mutableCopy.getY(), (double)(blockPos.getZ() + 1));
            if (!this.holes3x1.contains(box) && this.holes3x1.stream().noneMatch((box2) -> box2.intersects(box))) {
               this.holes3x1.add(box);
            }
         }
      }

      if (this.isValid3x1HoleSectionZ(blockPos)) {
         BlockPos.Mutable mutableCopy2 = blockPos.mutableCopy();

         while(this.isValid3x1HoleSectionZ(mutableCopy2)) {
            mutableCopy2.move(Direction.UP);
         }

         if (mutableCopy2.getY() - blockPos.getY() >= 8) {
            Box box3 = new Box((double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), (double)(blockPos.getX() + 1), (double)mutableCopy2.getY(), (double)(blockPos.getZ() + 3));
            if (this.holes3x1.contains(box3) || !this.holes3x1.stream().noneMatch((box4) -> box4.intersects(box3))) {
               return;
            }

            this.holes3x1.add(box3);
         }
      }

   }

   private boolean isValidHoleSection(BlockPos blockPos) {
      return this.isAirBlock(blockPos) && !this.isAirBlock(blockPos.north()) && !this.isAirBlock(blockPos.south()) && !this.isAirBlock(blockPos.east()) && !this.isAirBlock(blockPos.west());
   }

   private boolean isValid3x1HoleSectionX(BlockPos blockPos) {
      return this.isAirBlock(blockPos) && this.isAirBlock(blockPos.east()) && this.isAirBlock(blockPos.east(2)) && !this.isAirBlock(blockPos.north()) && !this.isAirBlock(blockPos.south()) && !this.isAirBlock(blockPos.east(3)) && !this.isAirBlock(blockPos.west()) && !this.isAirBlock(blockPos.east().north()) && !this.isAirBlock(blockPos.east().south()) && !this.isAirBlock(blockPos.east(2).north()) && !this.isAirBlock(blockPos.east(2).south());
   }

   private boolean isValid3x1HoleSectionZ(BlockPos blockPos) {
      return this.isAirBlock(blockPos) && this.isAirBlock(blockPos.south()) && this.isAirBlock(blockPos.south(2)) && !this.isAirBlock(blockPos.east()) && !this.isAirBlock(blockPos.west()) && !this.isAirBlock(blockPos.south(3)) && !this.isAirBlock(blockPos.north()) && !this.isAirBlock(blockPos.south().east()) && !this.isAirBlock(blockPos.south().west()) && !this.isAirBlock(blockPos.south(2).east()) && !this.isAirBlock(blockPos.south(2).west());
   }

   private boolean isAirBlock(BlockPos blockPos) {
      return this.mc.world == null ? false : this.mc.world.getBlockState(blockPos).isAir();
   }

   private void cleanupDistantHoles() {
      if (this.mc.player != null) {
         int intValue = (Integer)this.mc.options.getViewDistance().getValue();
         int x = this.mc.player.getChunkPos().x;
         int z = this.mc.player.getChunkPos().z;
         this.holes1x1.removeIf((box) -> Math.abs(Math.floorDiv((int)Math.floor(box.getCenter().getX()), 16) - x) > intValue || Math.abs(Math.floorDiv((int)Math.floor(box.getCenter().getZ()), 16) - z) > intValue);
         this.holes3x1.removeIf((box2) -> Math.abs(Math.floorDiv((int)Math.floor(box2.getCenter().getX()), 16) - x) > intValue || Math.abs(Math.floorDiv((int)Math.floor(box2.getCenter().getZ()), 16) - z) > intValue);
         this.holeScannedChunks.removeIf((chunkPos) -> Math.abs(chunkPos.x - x) > intValue || Math.abs(chunkPos.z - z) > intValue);
      }
   }

   private void scanChunksBackground() {
      if (!this.shouldStop && this.mc.world != null && this.mc.player != null && !this.isPausedDueToLag) {
         try {
            for(WorldChunk worldChunk : this.getLoadedChunks()) {
               if (!this.shouldStop && worldChunk != null && !worldChunk.isEmpty() && !this.isPausedDueToLag) {
                  ChunkPos pos = worldChunk.getPos();
                  if (!this.scannedChunks.contains(pos)) {
                     boolean contains = this.flaggedChunks.contains(pos);
                     Set<BlockPos> scanChunkForCoveredOres = this.scanChunkForCoveredOres(worldChunk);
                     if (!scanChunkForCoveredOres.isEmpty()) {
                        this.flaggedChunks.add(pos);
                        this.flaggedBlocks.put(pos, scanChunkForCoveredOres);
                        if (!contains && !this.notifiedChunks.contains(pos)) {
                           this.notifyChunkFound(pos);
                           this.notifiedChunks.add(pos);
                        }
                     } else {
                        this.flaggedChunks.remove(pos);
                        this.notifiedChunks.remove(pos);
                        this.flaggedBlocks.remove(pos);
                     }

                     this.scannedChunks.add(pos);
                     Thread.sleep(5L);
                  }
               }
            }
         } catch (InterruptedException var6) {
            Thread.currentThread().interrupt();
         } catch (Exception var7) {
         }

      }
   }

   private void notifyChunkFound(ChunkPos chunkPos) {
      this.mc.execute(() -> {
         try {
            if (this.mc.player != null) {
               this.mc.player.playSound(SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, 1.0F, 1.0F);
            }

            this.notifyFound(chunkPos.x * 16 + 8, chunkPos.z * 16 + 8);
         } catch (Exception var3) {
         }

      });
   }

   private Set<BlockPos> scanChunkForCoveredOres(WorldChunk worldChunk) {
      ConcurrentHashMap.KeySetView newKeySet = ConcurrentHashMap.newKeySet();
      int i = 0;
      if (!this.shouldStop && worldChunk != null && !worldChunk.isEmpty() && !this.isPausedDueToLag) {
         ChunkPos pos = worldChunk.getPos();
         int startX = pos.getStartX();
         int startZ = pos.getStartZ();
         int max = Math.max(worldChunk.getBottomY(), 20);
         int min = Math.min(worldChunk.getBottomY() + worldChunk.getHeight(), 60);

         for(int i2 = startX; i2 < startX + 16; ++i2) {
            for(int i3 = startZ; i3 < startZ + 16; ++i3) {
               for(int i4 = max; i4 < min; ++i4) {
                  if (this.shouldStop || this.isPausedDueToLag) {
                     return newKeySet;
                  }

                  BlockPos blockPos = new BlockPos(i2, i4, i3);

                  try {
                     BlockState blockState = worldChunk.getBlockState(blockPos);
                     Block block = blockState.getBlock();
                     if ((block == Blocks.TUFF || block == Blocks.DEEPSLATE) && i4 > 20 && i4 < 60 && this.isBlockCovered(worldChunk, blockPos) && this.isPositionUnderground(blockPos)) {
                        newKeySet.add(blockPos);
                     }

                     if (this.isTargetBlock(blockState) && i4 >= 20 && i4 <= 60 && this.isBlockCovered(worldChunk, blockPos) && this.isPositionUnderground(blockPos)) {
                        newKeySet.add(blockPos);
                     }

                     if (this.isRotatedDeepslate(blockState) && this.isBlockCovered(worldChunk, blockPos) && this.isPositionUnderground(blockPos)) {
                        newKeySet.add(blockPos);
                     }

                     // New scanner indicator: unusually long dripstone-block columns underground.
                     if (block == Blocks.DRIPSTONE_BLOCK && this.dripstoneLength(worldChunk, blockPos) >= 5
                           && this.isBlockCovered(worldChunk, blockPos) && this.isPositionUnderground(blockPos)) {
                        newKeySet.add(blockPos);
                     }

                     if (block == Blocks.PISTON || block == Blocks.STICKY_PISTON) {
                        ++i;
                     }
                  } catch (Exception var21) {
                  }
               }
            }
         }

         for(int i5 = startX; i5 < startX + 16; ++i5) {
            for(int i6 = startZ; i6 < startZ + 16; ++i6) {
               int i7 = 0;
               Block block2 = null;
               ArrayList<BlockPos> arrayList = new ArrayList();

               for(int i8 = max; i8 <= min; ++i8) {
                  BlockPos blockPos2 = new BlockPos(i5, i8, i6);
                  Block block3 = worldChunk.getBlockState(blockPos2).getBlock();
                  if (!this.isPlugBlock(block3)) {
                     i7 = 0;
                     block2 = null;
                     arrayList.clear();
                  } else {
                     if (block2 != null && block3 != block2) {
                        i7 = 1;
                        block2 = block3;
                        arrayList.clear();
                        arrayList.add(blockPos2);
                     } else {
                        ++i7;
                        block2 = block3;
                        arrayList.add(blockPos2);
                     }

                     if (i7 >= 25 && this.isCoveredColumn(worldChunk, i5, i6, i8 - i7 + 1, i8, block2)) {
                        ArrayList arrayList2 = new ArrayList();

                        for(BlockPos blockPos3 : arrayList) {
                           if (this.isBlockCovered(worldChunk, blockPos3) && this.isPositionUnderground(blockPos3)) {
                              arrayList2.add(blockPos3);
                           }
                        }

                        newKeySet.addAll(arrayList2);
                     }
                  }
               }
            }
         }

         if (i >= 5) {
            for(int i9 = startX; i9 < startX + 16; ++i9) {
               for(int i10 = startZ; i10 < startZ + 16; ++i10) {
                  for(int i11 = max; i11 < min && !this.shouldStop && !this.isPausedDueToLag; ++i11) {
                     BlockPos blockPos4 = new BlockPos(i9, i11, i10);

                     try {
                        Block block4 = worldChunk.getBlockState(blockPos4).getBlock();
                        if (block4 == Blocks.PISTON || block4 == Blocks.STICKY_PISTON) {
                           newKeySet.add(blockPos4);
                        }
                     } catch (Exception var20) {
                     }
                  }
               }
            }
         }

         return newKeySet;
      } else {
         return newKeySet;
      }
   }


   private int dripstoneLength(WorldChunk chunk, BlockPos start) {
      int length = 0;
      BlockPos.Mutable pos = start.mutableCopy();
      int topY = chunk.getBottomY() + chunk.getHeight();
      while (pos.getY() < topY && chunk.getBlockState(pos).isOf(Blocks.DRIPSTONE_BLOCK)) {
         length++;
         pos.move(Direction.UP);
      }
      pos.set(start).move(Direction.DOWN);
      while (pos.getY() >= chunk.getBottomY() && chunk.getBlockState(pos).isOf(Blocks.DRIPSTONE_BLOCK)) {
         length++;
         pos.move(Direction.DOWN);
      }
      return length;
   }

   private boolean isPlugBlock(Block block) {
      return block == Blocks.GRANITE || block == Blocks.ANDESITE || block == Blocks.DIRT || block == Blocks.DIORITE;
   }

   private boolean isCoveredColumn(WorldChunk worldChunk, int i, int i2, int i3, int i4, Block block) {
      for(int i5 = i3; i5 <= i4; ++i5) {
         BlockPos blockPos = new BlockPos(i, i5, i2);
         if (!worldChunk.getBlockState(blockPos).isOf(block)) {
            return false;
         }

         Direction[] values = Direction.values();
         int length = values.length;

         for(int i6 = 0; i6 < length; ++i6) {
            BlockPos offset = blockPos.offset(values[i6]);
            BlockState blockState = worldChunk.getBlockState(offset);
            if (blockState.isAir() || !blockState.isSolidBlock(this.mc.world, offset)) {
               return false;
            }
         }
      }

      return true;
   }

   private boolean isPositionUnderground(BlockPos blockPos) {
      if (this.mc.world == null) {
         return false;
      } else {
         int min = Math.min(blockPos.getY() + 50, 80);
         int i = 0;

         for(int y = blockPos.getY() + 1; y <= min; ++y) {
            BlockPos blockPos2 = new BlockPos(blockPos.getX(), y, blockPos.getZ());
            BlockState blockState = this.mc.world.getBlockState(blockPos2);
            if (!blockState.isAir() && blockState.isSolidBlock(this.mc.world, blockPos2)) {
               ++i;
            }
         }

         return i >= 3;
      }
   }

   private boolean isTargetBlock(BlockState blockState) {
      if (blockState != null && !blockState.isAir()) {
         Block block = blockState.getBlock();
         return block == Blocks.DEEPSLATE ? !this.isRotatedDeepslate(blockState) : block == Blocks.TUFF;
      } else {
         return false;
      }
   }

   private boolean isRotatedDeepslate(BlockState blockState) {
      if (blockState != null && !blockState.isAir() && blockState.getBlock() == Blocks.DEEPSLATE && blockState.contains(PillarBlock.AXIS)) {
         Direction.Axis axis = (Direction.Axis)blockState.get(PillarBlock.AXIS);
         return axis == Axis.X || axis == Axis.Z;
      } else {
         return false;
      }
   }

   private boolean isBlockCovered(WorldChunk worldChunk, BlockPos blockPos) {
      Direction[] directionArr = new Direction[]{Direction.UP, Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
      int length = directionArr.length;

      for(int i = 0; i < length; ++i) {
         BlockPos offset = blockPos.offset(directionArr[i]);

         try {
            if (this.mc.world == null) {
               return false;
            }

            BlockState blockState = this.mc.world.getBlockState(offset);
            if (blockState.isAir() || this.isTransparentBlock(blockState) || !blockState.isSolidBlock(this.mc.world, offset)) {
               return false;
            }
         } catch (Exception var8) {
            return false;
         }
      }

      return true;
   }

   private boolean isTransparentBlock(BlockState blockState) {
      Block block = blockState.getBlock();
      return block == Blocks.GLASS || block == Blocks.WATER || block == Blocks.LAVA || block == Blocks.ICE || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE || block == Blocks.WHITE_STAINED_GLASS || block == Blocks.ORANGE_STAINED_GLASS || block == Blocks.MAGENTA_STAINED_GLASS || block == Blocks.LIGHT_BLUE_STAINED_GLASS || block == Blocks.YELLOW_STAINED_GLASS || block == Blocks.LIME_STAINED_GLASS || block == Blocks.PINK_STAINED_GLASS || block == Blocks.GRAY_STAINED_GLASS || block == Blocks.LIGHT_GRAY_STAINED_GLASS || block == Blocks.CYAN_STAINED_GLASS || block == Blocks.PURPLE_STAINED_GLASS || block == Blocks.BLUE_STAINED_GLASS || block == Blocks.BROWN_STAINED_GLASS || block == Blocks.GREEN_STAINED_GLASS || block == Blocks.RED_STAINED_GLASS || block == Blocks.BLACK_STAINED_GLASS || block == Blocks.TINTED_GLASS || block == Blocks.OAK_LEAVES || block == Blocks.SPRUCE_LEAVES || block == Blocks.BIRCH_LEAVES || block == Blocks.JUNGLE_LEAVES || block == Blocks.ACACIA_LEAVES || block == Blocks.DARK_OAK_LEAVES || block == Blocks.MANGROVE_LEAVES || block == Blocks.CHERRY_LEAVES;
   }

   private void cleanupDistantChunks() {
      if (this.mc.player != null) {
         int intValue = (Integer)this.mc.options.getViewDistance().getValue();
         int x = this.mc.player.getChunkPos().x;
         int z = this.mc.player.getChunkPos().z;
         this.flaggedChunks.removeIf((chunkPos) -> {
            boolean z2 = Math.abs(chunkPos.x - x) > intValue || Math.abs(chunkPos.z - z) > intValue;
            if (z2) {
               this.flaggedBlocks.remove(chunkPos);
            }

            return z2;
         });
         this.scannedChunks.removeIf((chunkPos2) -> Math.abs(chunkPos2.x - x) > intValue || Math.abs(chunkPos2.z - z) > intValue);
         this.notifiedChunks.removeIf((chunkPos3) -> Math.abs(chunkPos3.x - x) > intValue || Math.abs(chunkPos3.z - z) > intValue);
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent render3DEvent) {
      if (this.mc.player == null || this.mc.world == null || this.killSwitchActivated) return;
      Camera camera = RenderUtils.getCamera();
      Vec3d cameraPos = RenderUtils.getCameraPos();
      if (camera == null || cameraPos == null || render3DEvent.matrixStack == null) return;

      MatrixStack matrixStack = render3DEvent.matrixStack;
      matrixStack.push();
      try {
         matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
         matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
         matrixStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

         for (ChunkPos chunkPos : this.flaggedChunks) {
            this.renderChunkHighlight(matrixStack, chunkPos, new Color(0, 255, 0, 120));
            this.renderFlaggedBlocks(matrixStack, chunkPos);
         }
         if (this.holeESP.getValue()) {
            if (!this.holes1x1.isEmpty()) this.renderHoles1x1(matrixStack);
            if (!this.holes3x1.isEmpty()) this.renderHoles3x1(matrixStack);
         }
      } finally {
         matrixStack.pop();
      }
   }

   private void renderHoles1x1(MatrixStack matrixStack) {
      Color color = this.hole1x1Color;

      for(Box box : this.holes1x1) {
         RenderUtils.renderFilledBox(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, color);
         this.renderBoxOutline(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, new Color(color.getRed(), color.getGreen(), color.getBlue(), 255));
      }

   }

   private void renderHoles3x1(MatrixStack matrixStack) {
      Color color = this.hole3x1Color;

      for(Box box : this.holes3x1) {
         RenderUtils.renderFilledBox(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, color);
         this.renderBoxOutline(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, new Color(color.getRed(), color.getGreen(), color.getBlue(), 255));
      }

   }

   private void renderChunkHighlight(MatrixStack matrixStack, ChunkPos chunkPos, Color color) {
      Box box = new Box((double)(chunkPos.x * 16), (double)60.0F, (double)(chunkPos.z * 16), (double)(chunkPos.x * 16 + 16), 60.100000001490116, (double)(chunkPos.z * 16 + 16));
      RenderUtils.renderFilledBox(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, color);
      this.renderBoxOutline(matrixStack, (float)box.minX, (float)box.minY, (float)box.minZ, (float)box.maxX, (float)box.maxY, (float)box.maxZ, color);
   }

   private void renderFlaggedBlocks(MatrixStack matrixStack, ChunkPos chunkPos) {
      Set<BlockPos> set = this.flaggedBlocks.get(chunkPos);
      if (set == null || set.isEmpty()) return;
      Color fillColor = new Color(255, 0, 0, 90);
      Color outlineColor = new Color(255, 40, 40, 230);
      for (BlockPos pos : set) {
         Box box = new Box(pos);
         RenderUtils.renderFilledBox(matrixStack, (float) box.minX, (float) box.minY,
               (float) box.minZ, (float) box.maxX, (float) box.maxY, (float) box.maxZ, fillColor);
         this.renderBoxOutline(matrixStack, (float) box.minX, (float) box.minY,
               (float) box.minZ, (float) box.maxX, (float) box.maxY, (float) box.maxZ, outlineColor);
      }
   }

   private List<WorldChunk> getLoadedChunks() {
      ArrayList<WorldChunk> arrayList = new ArrayList<>();
      if (this.mc.world == null || this.mc.player == null) return arrayList;
      int intValue = (Integer)this.mc.options.getViewDistance().getValue();

      for(int i = -intValue; i <= intValue; ++i) {
         for(int i2 = -intValue; i2 <= intValue; ++i2) {
            WorldChunk worldChunk = this.mc.world.getChunkManager().getWorldChunk(this.mc.player.getChunkPos().x + i, this.mc.player.getChunkPos().z + i2);
            if (worldChunk != null) {
               arrayList.add(worldChunk);
            }
         }
      }

      return arrayList;
   }

   private void renderBoxOutline(MatrixStack matrixStack, float f, float f2, float f3, float f4, float f5, float f6, Color color) {
      Vec3d[] vec3dArr = new Vec3d[]{new Vec3d((double)f, (double)f2, (double)f3), new Vec3d((double)f4, (double)f2, (double)f3), new Vec3d((double)f4, (double)f2, (double)f6), new Vec3d((double)f, (double)f2, (double)f6), new Vec3d((double)f, (double)f5, (double)f3), new Vec3d((double)f4, (double)f5, (double)f3), new Vec3d((double)f4, (double)f5, (double)f6), new Vec3d((double)f, (double)f5, (double)f6)};
      RenderUtils.renderLine(matrixStack, color, vec3dArr[0], vec3dArr[1]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[1], vec3dArr[2]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[2], vec3dArr[3]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[3], vec3dArr[0]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[4], vec3dArr[5]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[5], vec3dArr[6]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[6], vec3dArr[7]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[7], vec3dArr[4]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[0], vec3dArr[4]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[1], vec3dArr[5]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[2], vec3dArr[6]);
      RenderUtils.renderLine(matrixStack, color, vec3dArr[3], vec3dArr[7]);
   }

   private void notifyFound(int x, int z) {
      ++this.foundCount;
      String coords = "X: " + x + "  Z: " + z;
      boolean shown = false;
      if (this.toastNotify.getValue()) {
         shown = ToastUtil.show("Chunk Finder (" + this.foundCount + " found)", coords);
      }

      // Chat when requested, or as a fallback if the toast was enabled but could not be shown.
      boolean wantChat = this.chatNotify.getValue() || this.toastNotify.getValue() && !shown;
      if (wantChat && this.mc.inGameHud != null) {
         this.mc.inGameHud.getChatHud().addMessage(Text.literal("[ChunkFinder] " + coords));
      }

   }
}
