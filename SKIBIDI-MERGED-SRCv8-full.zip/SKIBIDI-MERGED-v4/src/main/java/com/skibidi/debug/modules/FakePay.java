package com.skibidi.debug.modules;

import com.skibidi.debug.SkibidiCategory;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class FakePay
extends Module {
    public static FakePay INSTANCE;
    private final SettingGroup sg;
    public final Setting<String> command;
    public final Setting<String> currency;
    public final Setting<Boolean> actionBar;
    public final Setting<Boolean> blockActual;

    public FakePay() {
        super(SkibidiCategory.MISC_V2, "fake-pay", "Intercepts /pay commands and shows a fake payment receipt.");
        this.sg = this.settings.getDefaultGroup();
        this.command = this.sg.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("command")).description("Command to intercept (without /).")).defaultValue("pay")).build());
        this.currency = this.sg.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("currency")).description("Currency symbol shown in receipt.")).defaultValue("$")).build());
        this.actionBar = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("action-bar")).description("Show receipt in action bar instead of chat.")).defaultValue(false)).build());
        this.blockActual = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("block-command")).description("Block the real /pay command from being sent.")).defaultValue(true)).build());
        INSTANCE = this;
    }

    public String[] parse(String cmd) {
        if (cmd == null) {
            return null;
        }
        String stripped = cmd.startsWith("/") ? cmd.substring(1).trim() : cmd.trim();
        String[] tokens = stripped.split("\\s+");
        if (tokens.length < 3) {
            return null;
        }
        if (!tokens[0].equalsIgnoreCase((String)this.command.get())) {
            return null;
        }
        return new String[]{tokens[1], tokens[2]};
    }

    public void showReceipt(String player, String rawAmount) {
        if (this.mc.field_1724 == null) {
            return;
        }
        String formatted = FakePay.formatAmount(rawAmount);
        class_5250 msg = class_2561.method_43473().method_10852((class_2561)class_2561.method_43470((String)"You paid ").method_27692(class_124.field_1068)).method_10852((class_2561)class_2561.method_43470((String)player).method_27692(class_124.field_1068)).method_10852((class_2561)class_2561.method_43470((String)(" " + (String)this.currency.get() + " ")).method_27692(class_124.field_1060)).method_10852((class_2561)class_2561.method_43470((String)formatted).method_27692(class_124.field_1068));
        this.mc.field_1724.method_7353((class_2561)msg, ((Boolean)this.actionBar.get()).booleanValue());
    }

    private static String formatAmount(String raw) {
        int last;
        String clean = raw.replace(",", "");
        int n = last = clean.isEmpty() ? 0 : (int)Character.toLowerCase(clean.charAt(clean.length() - 1));
        if (last == 107 || last == 109 || last == 98 || last == 116) {
            return raw.toUpperCase();
        }
        try {
            double v = Double.parseDouble(clean);
            if (v == Math.floor(v)) {
                return String.format("%,.0f", v);
            }
            return String.format("%,.2f", v);
        }
        catch (NumberFormatException e) {
            return raw;
        }
    }
}

