package dev.custommodels.addon.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.custommodels.addon.CustomModelState;
import dev.custommodels.addon.render.CustomPlayerModels;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.ModelCommandRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @WrapOperation(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/texture/Sprite;ILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"))
    private void custommodels$submitModel(
            OrderedRenderCommandQueue queue,
            Model<?> model,
            Object state,
            MatrixStack matrices,
            RenderLayer layer,
            int light,
            int overlay,
            int tint,
            Sprite sprite,
            int outline,
            ModelCommandRenderer.CrumblingOverlayCommand crumbling,
            Operation<Void> original) {
        if (state instanceof PlayerEntityRenderState playerState
                && state instanceof CustomModelState custom
                && model instanceof PlayerEntityModel playerModel) {
            if (custom.goobaa$hasCustomModel()
                    && CustomPlayerModels.render(
                            custom.goobaa$getCustomModel(),
                            playerModel,
                            playerState,
                            matrices,
                            queue,
                            light,
                            overlay,
                            tint,
                            outline)) {
                return;
            }
        }
        original.call(queue, model, state, matrices, layer, light, overlay, tint, sprite, outline, crumbling);
    }
}
